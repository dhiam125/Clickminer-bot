
# ClickMiner Bot ⛏️

بوت تليغرام بسيط يتيح للمستخدمين كسب عملات رمزية بالنقر.
يحتوي على قاعدة بيانات SQLite ونظام سحب.

## المتطلبات
- Python 3.10+
- مكتبات: python-telegram-bot, sqlite3

## التشغيل
1. ضع التوكن داخل الكود.
2. نفّذ: `python clickminer_bot.py`
